<template>
  <div>
    
  </div>
</template>

<script>
export default {
  name: "home",
  data() {
    return {
      
    }
  },
  components: {

  },
  methods: {
    
  },
  created() {
    this.$router.replace({
      path: '/blog'
    });
  },
  mounted() {
    
  }
};
</script>

<style scoped> 
  
</style>
