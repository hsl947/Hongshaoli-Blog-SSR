import '@@/static/js/highlight/monokai-sublime.min.css'
// require styles
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'